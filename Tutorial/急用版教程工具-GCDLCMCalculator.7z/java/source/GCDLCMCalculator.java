/**
 * # 计算最小公倍数
 * java -jar GCDLCMCalculator.jar lcm 24 1000
 * # 计算分数最大公约数
 * java -jar GCDLCMCalculator.jar fracgcd 1 90000 1001 24000
 */
public class GCDLCMCalculator {
    /**
     * 最大公约数函数，参数和返回值均为双精度浮点数
     */
    public static double gcd(double a, double b) {
        if (b == 0) { return a; }
        else { return gcd(b, a % b); }
    }
    /**
     * 最小公倍数函数，参数和返回值均为双精度浮点数
     */
    public static double lcm(double a, double b) {
        if (a == 0 && b == 0) { return 0; }
        double z = gcd(a, b);
        return Math.abs(a * b) / z;
    }
    /**
     * 计算分数的最大公约数，输入整数分子1，分母1，分子2，分母2
     */
    public static String fracGCD(int num1, int denom1, int num2, int denom2) {
        double gcdNums = gcd(num1, num2);
        double lcmDenoms = lcm(denom1, denom2);
        return (int)gcdNums + "/" + (int)lcmDenoms;
    }
    /**
     * 显示用法信息
     */
    public static void showUsage() {
        System.out.println("  ===== 用法 =====");
        System.out.println("java -jar GCDLCMCalculator.jar                                         # 运行演示");
        System.out.println("java -jar GCDLCMCalculator.jar gcd <a> <b>                             # 计算最大公约数");
        System.out.println("java -jar GCDLCMCalculator.jar lcm <a> <b>                             # 计算最小公倍数");
        System.out.println("java -jar GCDLCMCalculator.jar fracgcd <num1> <denom1> <num2> <denom2> # 计算分数的最大公约数");
    }
    /**
     * 主函数
     */
    public static void main(String[] args) {
        showUsage();
        if (args.length == 0) {
            System.out.println("\n  ===== 演示 =====");
            double result = lcm(24, 1000);
            System.out.println("24 与 1000 的最小公倍数为：" + result);
            String fracResult = fracGCD(1, 90000, 1001, 24000);
            System.out.println("1/90000 与 1001/24000 的最大公约数为：" + fracResult);
            return;
        }
        String operation = args[0].toLowerCase();
        
        switch (operation) {
            case "lcm":
                if (args.length == 3) {
                    try {
                        double a = Double.parseDouble(args[1]);
                        double b = Double.parseDouble(args[2]);
                        double result = lcm(a, b);
                        System.out.println(a + " 与 " + b + " 的最小公倍数为：" + result);
                    }
                    catch (NumberFormatException e) {
                        System.out.println("错误：请提供有效的数值参数");
                        showUsage();
                    }
                }
                else {
                    System.out.println("错误：请提供两个数值参数");
                    showUsage();
                }
                break;
            case "fracgcd":
                if (args.length == 5) {
                    try {
                        int num1 = Integer.parseInt(args[1]);
                        int denom1 = Integer.parseInt(args[2]);
                        int num2 = Integer.parseInt(args[3]);
                        int denom2 = Integer.parseInt(args[4]);
                        String result = fracGCD(num1, denom1, num2, denom2);
                        System.out.println(num1 + "/" + denom1 + " 与 " + num2 + "/" + denom2 + " 的最大公约数为：" + result);
                    }
                    catch (NumberFormatException e) {
                        System.out.println("错误：请提供有效的整数参数");
                        showUsage();
                    }
                }
                else {
                    System.out.println("错误：请提供四个分数参数");
                    showUsage();
                }
                break;
            default:
                showUsage();
                break;
        }
    }
}