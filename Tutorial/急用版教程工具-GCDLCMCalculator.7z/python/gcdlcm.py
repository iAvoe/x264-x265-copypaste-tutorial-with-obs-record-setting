#!/usr/bin/env python3
import sys
import argparse
import math

def gcd(a, b):
    """最大公约数函数，参数和返回值均为浮点数"""
    a, b = float(a), float(b)
    if b == 0: 
        return a
    else: 
        return gcd(b, a % b)

def lcm(a, b):
    """最小公倍数函数，参数和返回值均为浮点数"""
    a, b = float(a), float(b)
    if a == 0 and b == 0: 
        return 0
    z = gcd(a, b)
    return abs(a * b) / z

def frac_gcd(num1, denom1, num2, denom2):
    """计算分数的最大公约数，输入整数分子1，分母1，分子2，分母2"""
    gcd_nums = gcd(num1, num2)
    lcm_denoms = lcm(denom1, denom2)
    return f"{int(gcd_nums)}/{int(lcm_denoms)}"

def main():
    parser = argparse.ArgumentParser(description='计算最大公约数(GCD)和最小公倍数(LCM)')
    parser.add_argument('-o', '--operation', type=str, default='', help='操作类型: gcd, lcm, fracgcd')
    parser.add_argument('-a', '--A', type=float, help='第一个数值')
    parser.add_argument('-b', '--B', type=float, help='第二个数值')
    parser.add_argument('-num1', '--Num1', type=int, help='第一个分数的分子')
    parser.add_argument('-denom1', '--Denom1', type=int, help='第一个分数的分母')
    parser.add_argument('-num2', '--Num2', type=int, help='第二个分数的分子')
    parser.add_argument('-denom2', '--Denom2', type=int, help='第二个分数的分母')
    parser.add_argument('values', nargs='*', help='位置参数')
    
    args = parser.parse_args()
    
    # 处理位置参数
    if args.values:
        if args.values[0].lower() in ['gcd', 'lcm', 'fracgcd']:
            args.operation = args.values[0].lower()
            args.values = args.values[1:]
        
        if args.operation == 'gcd' or args.operation == 'lcm':
            if len(args.values) >= 2:
                args.A = float(args.values[0])
                args.B = float(args.values[1])
        elif args.operation == 'fracgcd':
            if len(args.values) >= 4:
                args.Num1 = int(args.values[0])
                args.Denom1 = int(args.values[1])
                args.Num2 = int(args.values[2])
                args.Denom2 = int(args.values[3])
    
    # 根据操作类型执行相应计算
    if args.operation.lower() == 'gcd':
        if args.A is not None and args.B is not None:
            result = gcd(args.A, args.B)
            print(f"{args.A} 与 {args.B} 的最大公约数为: {result}")
        else:
            print("错误: 请提供两个数值参数 -A 和 -B")
    
    elif args.operation.lower() == 'lcm':
        if args.A is not None and args.B is not None:
            result = lcm(args.A, args.B)
            print(f"{args.A} 与 {args.B} 的最小公倍数为: {result}")
        else:
            print("错误: 请提供两个数值参数 -A 和 -B")
    
    elif args.operation.lower() == 'fracgcd':
        if all(x is not None for x in [args.Num1, args.Denom1, args.Num2, args.Denom2]):
            result = frac_gcd(args.Num1, args.Denom1, args.Num2, args.Denom2)
            print(f"{args.Num1}/{args.Denom1} 与 {args.Num2}/{args.Denom2} 的最大公约数为: {result}")
        else:
            print("错误: 请提供分数参数 -Num1, -Denom1, -Num2, -Denom2")
    
    else:
        # 显示用法和演示
        print("\n  ===== 用法 =====")
        print("  python gcdlcm.py -o gcd -a 24 -b 1000                                      # 计算最大公约数")
        print("  python gcdlcm.py -o gcd 24 1000                                            # 计算最大公约数")
        print("  python gcdlcm.py -o lcm -a 24 -b 1000                                      # 计算最小公倍数")
        print("  python gcdlcm.py -o lcm 24 1000                                            # 计算最小公倍数")
        print("  python gcdlcm.py -o fracgcd -num1 1 -denom1 90000 -num2 1001 -denom2 24000 # 计算分数的最大公约数")
        print("  python gcdlcm.py -o fracgcd 1 90000 1001 24000                             # 计算分数的最大公约数")
        
        print("\n  ===== 演示 =====")
        result = gcd(24, 1000)
        print(f"24 与 1000 的最大公约数为: {result}")
        result = lcm(24, 1000)
        print(f"24 与 1000 的最小公倍数为: {result}")
        result = frac_gcd(1, 90000, 1001, 24000)
        print(f"1/90000 与 1001/24000 的最大公约数为: {result}")

if __name__ == "__main__":
    main()