选择使用 PowerShell、Python、Bash（.sh）、Java（.jar）计算最大公约数（Greatest common denominator、GCD）、最小公倍数（Least common multiple、LCM），或者分数的最大公约数（Fraction GCD、fracGCD），以便在统计 ffmpeg XPSNR、VMAF（衡量压缩前后画质差距）所需的时间基（timebase）对齐操作。

## Motivation

若源与压缩结果两个视频流的时间基不对齐，ffmpeg 就会警报“DTS 未单调增加（DTS is not monotonically increasing）”，并且在开始跑分钱警告：
```
[Parsed_xpsnr_0 @ 000001e437db6e80]
not matching timebases found between first input: 1/90000 and second input 1001/24000, results may be incorrect!
```

并且，最终画质衡量分数大概率会远低于正常：

- 未对齐（画质 -659%）：
```
XPSNR average, 14315 frames  y: 33.8192  u: 41.5568  v: 42.3078 (minimum: 33.8192)
```
- 对齐：
```
XPSNR average, 14315 frames  y: 41.9978  u: 44.6105  v: 45.2615  (minimum: 41.9978)
```

## 示例

### XPSNR（普通版本）
```
ffmpeg -i ".\原画源.mkv" -i ".\压缩源.ivf" -lavfi xpsnr="stats_file=-" -f null -
```
### XPSNR（时间基对齐版本，批处理变量，批处理换行）
```
set "alignedTbase=输入最小公倍数lcm，如1234、或分数小数的最大公约数fracGCD结果，如1/360000"
ffmpeg -i ".\原画源.mkv" -i ".\压缩源.ivf" -lavfi ^
"[0:v]setpts=N*(%alignedTbase%)[src]; ^
[1:v]setpts=N*(%alignedTbase%)[enc]; ^
[src][enc]xpsnr=stats_file=-" -f null -
```
### VMAF（普通版本，批处理换行）
```
ffmpeg -i ".\原画源.mkv" -i ".\压缩源.ivf" -lavfi ^
libvmaf="model=version=vmaf_4k_v0.6.1\\:name=vmaf_4k|version=vmaf_v0.6.1\\:name=vmaf_1080p" ^
-f null -
```
### VMAF（时间基对齐版本，批处理变量，批处理换行）
```
set "alignedTbase=输入最小公倍数lcm，如1234、或分数小数的最大公约数fracGCD结果，如1/360000"
ffmpeg -i ".\原画源.mkv" -i ".\压缩源.ivf" -lavfi ^
"[0:v]setpts=N*(%alignedTbase%)[src]; ^
[1:v]setpts=N*(%alignedTbase%)[enc]; ^
[src][enc]libvmaf=model=version=vmaf_4k_v0.6.1\\:name=vmaf_4k|version=vmaf_v0.6.1\\:name=vmaf_1080p" ^
-f null -
```

## 用法
先运行普通版本，看到 `not matching timebases found between first input: ??? and second input ???` 提醒时按 `Ctrl+C` 停止跑分，然后：

1. 按喜好选择一款脚本（在 [main](/) 目录下选择 PowerShell、Python、Bash（.sh）、Java（.jar）并下载）
2. 根据 ffmpeg `not matching ...` 反馈是否含有小数/分数，如果有就使用分数的最大公约数 fracGCD 算法、否则使用最小公倍数 lcm 算法
3. 查看帮助信息并运行

### PowerShell 脚本（Windows、可能支持 Linux？）
```
# 参数名用法（支持乱序参数指定）
.\gcdlcm.ps1 -Operation gcd -A 24 -B 1000
.\gcdlcm.ps1 -Operation lcm -A 24 -B 1000
.\gcdlcm.ps1 -Operation fracgcd -Num1 1 -Denom1 90000 -Num2 1001 -Denom2 24000

# 仅参数用法（仅支持顺序参数指定）
.\gcdlcm.ps1 -Operation gcd 24 1000
.\gcdlcm.ps1 -Operation lcm 24 1000
.\gcdlcm.ps1 -Operation fracgcd 1 90000 1001 24000

# 显示帮助信息
.\gcdlcm.ps1
```

### Java 包（需安装 Java 环境）
```
# 仅参数用法（支持乱序参数指定）
java -jar .\GCDLCMCalculator.jar gcd
java -jar .\GCDLCMCalculator.jar lcm
java -jar .\GCDLCMCalculator.jar fracgcd

# 显示帮助信息
java -jar .\GCDLCMCalculator.jar
```

### Python 脚本（需安装 Python 环境）
```
# 参数名用法（支持乱序参数指定）
python .\gcdlcm.py -o gcd -a 24 -b 1000
python .\gcdlcm.py -o lcm -a 24 -b 1000
python .\gcdlcm.py -o fracgcd -num1 1 -denom1 90000 -num2 1001 -denom2 24000

# 仅参数用法（仅支持顺序参数指定）
python .\gcdlcm.py gcd 24 1000
python .\gcdlcm.py lcm 24 1000
python .\gcdlcm.py fracgcd 1 90000 1001 24000

# 显示帮助信息
python .\gcdlcm.py
```

### Bash 脚本（Linux、Git Bash、可能支持 Mac OS？）
```
# 参数名用法（支持乱序参数指定）
./gcdlcm.sh -o gcd -a 24 -b 1000
./gcdlcm.sh -o lcm -a 24 -b 1000
./gcdlcm.sh -o fracgcd -num1 1 -denom1 90000 -num2 1001 -denom2 24000

# 仅参数用法（仅支持顺序参数指定）
./gcdlcm.sh gcd 24 1000
./gcdlcm.sh lcm 24 1000
./gcdlcm.sh fracgcd 1 90000 1001 24000

# 显示帮助信息
./gcdlcm.sh
```
