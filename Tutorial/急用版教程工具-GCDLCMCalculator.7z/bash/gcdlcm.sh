#!/bin/bash

# 最大公约数函数
gcd() {
    local a=$1 b=$2
    if (( $(echo "$b == 0" | bc -l) )); then 
        echo "$a"
    else 
        gcd "$b" $(echo "$a % $b" | bc -l)
    fi
}

# 最小公倍数函数
lcm() {
    local a=$1 b=$2
    if (( $(echo "$a == 0 && $b == 0" | bc -l) )); then 
        echo "0"
        return
    fi
    local gcd_result=$(gcd "$a" "$b")
    local product=$(echo "$a * $b" | bc -l)
    local abs_product=$(echo "sqrt($product * $product)" | bc -l)
    echo "scale=10; $abs_product / $gcd_result" | bc -l | sed 's/\.0*$//; s/\.$//'
}

# 计算分数的最大公约数
frac_gcd() {
    local num1=$1 denom1=$2 num2=$3 denom2=$4
    local gcd_nums=$(gcd "$num1" "$num2")
    local lcm_denoms=$(lcm "$denom1" "$denom2")
    echo "${gcd_nums}/${lcm_denoms}"
}

# 显示用法信息
show_usage() {
    echo ""
    echo "  ===== 用法 ====="
    echo "  $0 -o gcd -a 24 -b 1000                                      # 计算最大公约数"
    echo "  $0 -o gcd 24 1000                                            # 计算最大公约数"
    echo "  $0 -o lcm -a 24 -b 1000                                      # 计算最小公倍数"
    echo "  $0 -o lcm 24 1000                                            # 计算最小公倍数"
    echo "  $0 -o fracgcd -num1 1 -denom1 90000 -num2 1001 -denom2 24000 # 计算分数的最大公约数"
    echo "  $0 -o fracgcd 1 90000 1001 24000                             # 计算分数的最大公约数"
    echo ""
    echo "  ===== 演示 ====="
    result=$(gcd 24 1000)
    echo "24 与 1000 的最大公约数为: $result"
    result=$(lcm 24 1000)
    echo "24 与 1000 的最小公倍数为: $result"
    result=$(frac_gcd 1 90000 1001 24000)
    echo "1/90000 与 1001/24000 的最大公约数为: $result"
}

# 解析参数
parse_args() {
    OPERATION=""
    A=""
    B=""
    NUM1=""
    DENOM1=""
    NUM2=""
    DENOM2=""
    POSITIONAL=()
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            -o|--operation)
                OPERATION="$2"
                shift
                shift
                ;;
            -a|--A)
                A="$2"
                shift
                shift
                ;;
            -b|--B)
                B="$2"
                shift
                shift
                ;;
            -num1|--Num1)
                NUM1="$2"
                shift
                shift
                ;;
            -denom1|--Denom1)
                DENOM1="$2"
                shift
                shift
                ;;
            -num2|--Num2)
                NUM2="$2"
                shift
                shift
                ;;
            -denom2|--Denom2)
                DENOM2="$2"
                shift
                shift
                ;;
            -*|--*)
                echo "未知选项: $1"
                exit 1
                ;;
            *)
                POSITIONAL+=("$1")
                shift
                ;;
        esac
    done
    
    # 处理位置参数
    if [ ${#POSITIONAL[@]} -gt 0 ]; then
        if [[ "${POSITIONAL[0]}" =~ ^(gcd|lcm|fracgcd)$ ]]; then
            OPERATION="${POSITIONAL[0]}"
            POSITIONAL=("${POSITIONAL[@]:1}")
        fi
        
        if [ "$OPERATION" = "gcd" ] || [ "$OPERATION" = "lcm" ]; then
            if [ ${#POSITIONAL[@]} -ge 2 ]; then
                A="${POSITIONAL[0]}"
                B="${POSITIONAL[1]}"
            fi
        elif [ "$OPERATION" = "fracgcd" ]; then
            if [ ${#POSITIONAL[@]} -ge 4 ]; then
                NUM1="${POSITIONAL[0]}"
                DENOM1="${POSITIONAL[1]}"
                NUM2="${POSITIONAL[2]}"
                DENOM2="${POSITIONAL[3]}"
            fi
        fi
    fi
}

# 主函数
main() {
    parse_args "$@"
    
    # 根据操作类型执行相应计算
    case "$OPERATION" in
        "gcd")
            if [ -n "$A" ] && [ -n "$B" ]; then
                result=$(gcd "$A" "$B")
                echo "$A 与 $B 的最大公约数为: $result"
            else
                echo "错误: 请提供两个数值参数 -A 和 -B"
            fi
            ;;
        "lcm")
            if [ -n "$A" ] && [ -n "$B" ]; then
                result=$(lcm "$A" "$B")
                echo "$A 与 $B 的最小公倍数为: $result"
            else
                echo "错误: 请提供两个数值参数 -A 和 -B"
            fi
            ;;
        "fracgcd")
            if [ -n "$NUM1" ] && [ -n "$DENOM1" ] && [ -n "$NUM2" ] && [ -n "$DENOM2" ]; then
                result=$(frac_gcd "$NUM1" "$DENOM1" "$NUM2" "$DENOM2")
                echo "$NUM1/$DENOM1 与 $NUM2/$DENOM2 的最大公约数为: $result"
            else
                echo "错误: 请提供分数参数 -Num1, -Denom1, -Num2, -Denom2"
            fi
            ;;
        *)
            show_usage
            ;;
    esac
}

# 如果没有参数，显示用法
if [ $# -eq 0 ]; then
    show_usage
    exit 0
fi

main "$@"